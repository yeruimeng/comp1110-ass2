package comp1110.ass2;

public class Move {
    // method roll dice -> change statement
    // method build -> change statement
    // method trade -> change statement
    // method upgrade -> change statement
    // turn +1 -> change statement
    // next player -> save last player's move statement

}
