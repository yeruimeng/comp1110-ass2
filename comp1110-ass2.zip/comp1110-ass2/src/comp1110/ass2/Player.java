package comp1110.ass2;

public class Player {
    // initial player
    // constructor

}
