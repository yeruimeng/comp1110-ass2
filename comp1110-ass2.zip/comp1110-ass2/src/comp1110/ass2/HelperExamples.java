package comp1110.ass2;

public class HelperExamples {
    static String[] valid_board = {
            "R0,S3,R1,C7,R2,S4,R3,R4,R5,R6",
            "R0,S3,R1",
            "R0,S3,R1,C7,R2,S4,R3,R4,R5,R6",
            "R0,S3,R1",
            "R0,S3,R1,C7,R2,S4,R3,R4,R5,R6"
    };
    static String[] invalid_board = {
            "R0,S3,R1,C7,R2,S4,R3,R4,R5,R6",
            "R0,S3,R1",
            "R0,S3,R1,C7,R2,S4,R3,R4,R5,R6,K1,K2,K3",
            "R0,S3,R1,C7,R2,S4,R3,R4,R5,R6",
            "R0,S3,R1,C7,R2,S4,R3,R4,R5,R6,K1,K2,K3",
    };
    static String[] valid_target = {
            "C12",
            "R2",
            "S5",
            "C7",
            "R7"
    };
    static String[] invalid_target = {
            "R7",
            "R2",
            "S5",
            "C7",
            "R7"
    };
    static String[][][] valid_plans = {
            {{"build C12"}},
            {{"build R2"}},
            {{"build S5"}},
            {{"build C7"}},
            {{"build R7"}}
    };
    static String[][][] invalid_plans = {
            {{"build S7"}},
            {{"build R3"}},
            {{"build S3"}},
            {{"build C5"}},
            {{"build R6"}}
    };
}
