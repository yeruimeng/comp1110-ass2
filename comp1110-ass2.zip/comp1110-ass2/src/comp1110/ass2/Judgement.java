package comp1110.ass2;

public class Judgement {
    public Boolean isGameOver() {
        return false;
    }
    // method isGameOver (check turn == 15).
    public void checkWinner (Boolean isGameover) {}

    // method checkWinner (if isGameOver == true), sum each play's point, checkWinner.


}
