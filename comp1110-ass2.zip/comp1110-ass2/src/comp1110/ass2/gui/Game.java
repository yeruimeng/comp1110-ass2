package comp1110.ass2.gui;

import comp1110.ass2.CatanDice;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Paint;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

import java.awt.*;
import java.util.ArrayList;

public class Game extends Application { // Written by Renbin He

    private final Group root = new Group();
    private static final int WINDOW_WIDTH = 1200;
    private static final int WINDOW_HEIGHT = 700;

    private Pane gameBuilding = new Pane();
    private StackPane dataBoard = new StackPane();
    private TextField turn = new TextField(); // each turn +1
    private TextField score = new TextField(); // update score each turn
    private TextField stateHistory = new TextField(); // record the passed state
    private TextField resourceState = new TextField(); // current resource-state
    private TextField swap = new TextField();//input two index of resourceState, first one input, second one output. check by canDoAction
    private TextField trade = new TextField();//input one number, first one number is index of resource state that you want to trade
    private TextField build = new TextField();//input 2-3 length. first Capital char, rest are number,the current building you want to build, prefix is "build"
    private TextField rollOrder = new TextField();// input the index of resource-state then just re-roll those again.
    private Button rollDice =  new Button("Rolling Dice"); // press this to roll the dice (most three times each turn);
    private Button swapBT =  new Button("Swap");// According to the text-field swap to swap resource and affect to resourceState.
    private Button tradeBT = new Button("Trade");// According to the text-field trade to trade resource and affect to resourceState.
    private Button finalBuild = new Button("Finish Build"); // after set all resource and check, then press this button to finish build
                                                               //and move to the next turn.
    private Button jumpTurn = new Button("Jump this turn"); // if not any building can build, then press this button to start a new turn.
    private static int turnNum = 1;
    private static int rollTimes = 0;
    private static int[] savingResource = new int[6];
    private static String increasingState ="";
    private static int increasingScore = 0;
    private static int[] initResource = {0,0,0,0,0,0};


    @Override
    public void start(Stage stage) throws Exception {

        stage.setTitle("Square");
        Group root = new Group();
        Scene scene = new Scene(root, 300, 300);
        stage.setScene(scene);
        Rectangle r = new Rectangle(100, 100, 100, 100);
        r.setFill(Color.RED);

        stage.show();

    }
}
