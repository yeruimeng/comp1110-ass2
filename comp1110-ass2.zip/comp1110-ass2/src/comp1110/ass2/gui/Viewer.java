package comp1110.ass2.gui;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.util.ArrayList;

public class Viewer extends Application {

    private static final int VIEWER_WIDTH = 1200;
    private static final int VIEWER_HEIGHT = 700;

    private final Group root = new Group();
    private final Group controls = new Group();
//    private final StackPane gameBoard = new StackPane();
    private TextField playerTextField;
    private TextField boardTextField;


    /**
     * Show the state of a (single player's) board in the window.
     *
     * @param 'The' string representation of the board state.
     */
    //Written by Renbin He
    public void displayState(String board_state) {
        var separateState = board_state.split(",");
        for (String s: separateState) {
            if (s.length() == 2) {
                char c = s.charAt(0);
                char c1 = s.charAt(1);
                int realNum = (int)c1 -48;
                switch (c){
                    case 'R':
                        if (realNum == 2) {
                            getRtype("1",435,375);
                        } else if (realNum == 5) {
                            getRtype("1",435,585);
                        } else if (realNum == 8) {
                            getRtype("1",625,480);
                        } else if (realNum == 0) {
                            getRtype("2",435,280);
                        } else if (realNum == 3) {
                            getRtype("2",435,500);
                        } else if (realNum == 7) {
                            getRtype("2",625,605);
                        } else if (realNum == 9) {
                            getRtype("2",625,385);
                        } else if (realNum == 1) {
                            getRtype("3",352,347);
                        } else if (realNum == 4) {
                            getRtype("3",352,567);
                        } else if (realNum == 6) {
                            getRtype("3",545,670);
                        }break;
                    case 'S':
                        if (realNum == 3) {
                            getSType("3",480,220);
                        } else if (realNum == 4) {
                            getSType("4",480,445);
                        } else if (realNum == 5) {
                            getSType("5",490,650);
                        } else if (realNum == 7) {
                            getSType("7",675,548);
                        } else if (realNum == 9) {
                            getSType("9",668,338);
                        }break;
                    case 'C':
                        if (realNum == 7) {
                            getCType("7",282,330);
                        } break;
                    case 'J': //changed from K
                        if (realNum == 1) {
                            getKType("1",365,165);
                        } else if (realNum == 2) {
                            getKType("2",365,380);
                        } else if (realNum == 3) {
                            getKType("3",552,490);
                        } else if (realNum == 4) {
                            getKType("4",742,383);
                        } else if (realNum == 5) {
                            getKType("5",740,170);
                        } else if (realNum == 6) {
                            getKType("6",552,50);
                        }break;
                    case 'K': //change from J
                        if (realNum == 1) {
                            getJType("1",365,165);
                        } else if (realNum == 2) {
                            getJType("2",365,380);
                        } else if (realNum == 3) {
                            getJType("3",552,490);
                        } else if (realNum == 4) {
                            getJType("4",742,383);
                        } else if (realNum == 5) {
                            getJType("5",740,170);
                        } else if (realNum == 6) {
                            getJType("6",552,50);
                        }break;

                }
            } else if (s.length() == 3) {
                char c = s.charAt(0);
                char c1 = s.charAt(1);
                char c2 = s.charAt(2);
                int realNum1 = c1 -48;
                int realNum2 = c2 -48;
                int totalNum = realNum1*10 + realNum2;
                switch (c){
                    case 'R':
                        if (totalNum == 10) {
                            getRtype("1",625,260);
                        } else if (totalNum == 14) {
                            getRtype("1",805,370);
                        } else if (totalNum == 11) {
                            getRtype("2",625,165);
                        } else if (totalNum == 13) {
                            getRtype("2",810,495);
                        } else if (totalNum == 15) {
                            getRtype("2",815,275);
                        } else if (totalNum == 12) {
                            getRtype("3",735,562);
                        }break;
                    case 'S':
                        if (totalNum == 11) {
                            getSType("11",672,113);
                        }break;
                    case 'C':
                        if (totalNum == 12) {
                            getCType("12",282,545);
                        } else if (totalNum == 20) {
                            getCType("20",845,440);
                        } else if (totalNum == 30) {
                            getCType("30",845,220);
                        }break;
                }
            }
        }

        // FIXME Task 5: implement the state viewer
    }
    private void getRtype (String type,int x, int y) {
        ImageView imageR2type = new ImageView();
        Image imgR2type = new Image("image/R_type"+type+".png");
        imageR2type.setImage(imgR2type);
        imageR2type.setFitWidth(60);
        imageR2type.setPreserveRatio(true);
        imageR2type.setLayoutY(y);
        imageR2type.setLayoutX(x);
        root.getChildren().add(imageR2type);
    }

    private void getSType (String type, int x, int y) {
        ImageView imageSType = new ImageView();
        Image imgSType = new Image("image/S"+type+".png");
        imageSType.setImage(imgSType);
        imageSType.setFitWidth(40);
        imageSType.setPreserveRatio(true);
        imageSType.setLayoutX(x);
        imageSType.setLayoutY(y);
        root.getChildren().add(imageSType);
    }

    private void getCType (String type, int x, int y) {
        ImageView imageCType = new ImageView();
        Image imgCType = new Image("image/C"+type+".png");
        imageCType.setImage(imgCType);
        imageCType.setFitWidth(55);
        imageCType.setPreserveRatio(true);
        imageCType.setLayoutX(x);
        imageCType.setLayoutY(y);
        root.getChildren().add(imageCType);
    }

    private void getKType (String type, int x, int y) {
        ImageView imageKType = new ImageView();
        Image imgKType = new Image("image/K"+type+".png");
        imageKType.setImage(imgKType);
        imageKType.setFitWidth(35);
        imageKType.setPreserveRatio(true);
        imageKType.setLayoutX(x);
        imageKType.setLayoutY(y);
        root.getChildren().add(imageKType);
    }

    private void getJType (String type, int x, int y) {
        ImageView imageJType = new ImageView();
        Image imgJType = new Image("image/J"+type+".png");
        imageJType.setImage(imgJType);
        imageJType.setFitWidth(35);
        imageJType.setPreserveRatio(true);
        imageJType.setLayoutX(x);
        imageJType.setLayoutY(y);
        root.getChildren().add(imageJType);
    }



    private void getGameBoard () {
        ImageView imageGameBoard = new ImageView();
        Image imgGameBoard = new Image("image/gameBoard.png");
        imageGameBoard.setImage(imgGameBoard);
        imageGameBoard.setFitWidth(650);
        imageGameBoard.setPreserveRatio(true);
        imageGameBoard.setLayoutY(30);
        imageGameBoard.setTranslateX(250);
        root.getChildren().add(imageGameBoard);
    }

    /**
     * Create a basic text field for input and a refresh button.
     */
    private void makeControls() {
        Label boardLabel = new Label("Board State:");
        boardTextField = new TextField();
        boardTextField.setPrefWidth(500);
        Button button = new Button("Show");
        button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                displayState(boardTextField.getText());
            }
        });
        HBox hb = new HBox();
        hb.getChildren().addAll(boardLabel, boardTextField, button);
        hb.setSpacing(10);
        controls.getChildren().add(hb);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setTitle("Board State Viewer");
        Scene scene = new Scene(root, VIEWER_WIDTH, VIEWER_HEIGHT);

        root.getChildren().add(controls);

        makeControls();
        getGameBoard();

        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
