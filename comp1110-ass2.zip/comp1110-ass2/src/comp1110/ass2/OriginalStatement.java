package comp1110.ass2;

public class OriginalStatement {
    // resources setting
    // initial statement
    // getter setter
    // constructor

}
