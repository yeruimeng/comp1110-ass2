package comp1110.ass2;

import java.util.*;

public class CatanDice {
    public static boolean checkMeetsConstraints(String requirements, String board_state) {
        //check the requirements
        String[] req = requirements.split(",");
        String[] board = board_state.split(",");
        if (requirements.length() == 0) {
            return true;
        }
        //check the board state
        Set<String> boardStateHash = new HashSet<String>(Arrays.asList(board));
        for (String v : req) {
            if (!boardStateHash.contains(v)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Check if the string encoding of a board state is well formed.
     * Note that this does not mean checking if the state is valid
     * (represents a state that the player could get to in game play),
     * only that the string representation is syntactically well formed.
     *
     * @param board_state: The string representation of the board state.
     * @return true iff the string is a well-formed representation of
     *         a board state, false otherwise.
     */
    //Written by Renbin He
    public static boolean isBoardStateWellFormed(String board_state) {
//        System.out.println(board_state);
        if (board_state.length() == 1) {
            return false;
        } if (board_state.length() > 1) {
            return isBoardStateWell(board_state);
        }
        return true; // FIXME: Task #3
    }
    //helper function
    public static boolean isBoardStateWell(String board_state) {
        var separate = board_state.split(",");
        for (String s : separate) {
            if (s.length() > 3) {
                return false;
            } else if (s.length() == 2) {
                char c = s.charAt(0);
                char c1 = s.charAt(1);
                int realNum = (int) c1 -48;
                switch (c) {
                    case 'R':
                        if (realNum > 9 || realNum < 0) {
                            return false;
                        } break;
                    case 'S':
                        if (!(realNum == 3 || realNum == 4 || realNum == 5 || realNum == 7 || realNum == 9)) {
                            return false;
                        } break;
                    case 'C':
                        if (realNum != 7) {
                            return false;
                        } break;
                    case 'J':
                        if (realNum <= 0 || realNum > 6) {
                            return false;
                        } break;
                    case 'K':
                        if (realNum > 6 || realNum < 1) {
                            return false;
                        } break;
                    default:
                        return false;
                }
            } else if (s.length() == 3) {
                char c = s.charAt(0);
                char c1 = s.charAt(1);
                char c2 = s.charAt(2);
                int realNum1 = (int) c1 -48;
                int realNum2 = (int) c2 -48;
                int total_num = realNum1 * 10 + realNum2;
                if (realNum1 < 0 || realNum1 > 9 || realNum2 < 0 || realNum2 > 9) {
                    return false;
                }
                switch (c) {
                    case 'R':
                        if (total_num > 15 || total_num < 0) {
                            return false;
                        } break;
                    case 'J':
                        if (total_num < 0 || total_num > 6) {
                            return false;
                        } break;
                    case 'S':
                        if (!(total_num == 3 || total_num == 4 || total_num == 5 || total_num == 7 || total_num == 9
                                || total_num == 11)) {
                            return false;
                        } break;
                    case 'C':
                        if (!(total_num == 7 || total_num == 12 || total_num == 20 || total_num == 30)) {
                            return false;
                        } break;
                    default:
                        return false;
                }
            }
        }
        return true;
    }


    /**
     * Check if the string encoding of a player action is well formed.
     *
     * @param action: The string representation of the action.
     * @return true iff the string is a well-formed representation of
     *         a board state, false otherwise.
     */
    //Written by Renbin He
    public static boolean isActionWellFormed(String action) {
        var separate = action.split(" ");
        if (!(separate[0].contains("build") || separate[0].contains("swap") || separate[0].contains("trade"))) {
            return false;
        } else if (separate[0].contains("build")) {
            if (separate.length != 2) {
                return false;
            } else if (!(isBoardStateWellFormed(separate[1]))) {
                return false;
            }
        } else if (separate[0].contains("trade")) {
            if (separate.length != 2) {
                return false;
            } else if (separate[1].length() != 1) {
                return false;
            }
            var c = (int)separate[1].charAt(0) - 48;
            if (!(c == 0 || c == 1 || c == 2 || c == 3 || c == 4 || c == 5)) {
                return false;
            }
        } else if (separate[0].contains("swap")) {
            if (separate.length != 3) {
                return false;
            } else if (separate[1].length() != 1 || separate[2].length() != 1) {
                return false;
            }
            var c = (int)separate[1].charAt(0) - 48;
            var c1 = (int)separate[2].charAt(0) - 48;
            if (!(c == 0 || c == 1 || c == 2 || c == 3 || c == 4 || c == 5
                    || c1 == 0 || c1 == 1 || c1 == 2 || c1 == 3 || c1 == 4 || c1 == 5)) {
                return false;
            }
        }

	 return true; // FIXME: Task #4
    }

    /**
     * Roll the specified number of dice and add the result to the
     * resource state.
     *
     * The resource state on input is not necessarily empty. This
     * method should only _add_ the outcome of the dice rolled to
     * the resource state, not remove or clear the resources already
     * represented in it.
     *
     * @param n_dice: The number of dice to roll (>= 0).
     * @param resource_state: The available resources that the dice
     *        roll will be added to.
     *
     * This method does not return any value. It should update the given
     * resource_state.
     */

    //written by Ruimeng YE
    public static void rollDice(int n_dice, int[] resource_state) {
//        System.out.println(n_dice);
//        System.out.println(resource_state[0] +""+ resource_state[1] +""+ resource_state[2] +""+ resource_state[3] +""+ resource_state[4] +""+ resource_state[5]);
        Random rand=new Random();
        for (int i=0;i<n_dice;i++){
            int turn=rand.nextInt(6);
            resource_state[turn]++;
        }

	// FIXME: Task #6
    }

    public static void main(String[] args) {
        int[] temp = {1,1,1,1,1,1};
//        rollDice(6,temp);
//        System.out.println(temp[0] + " " + temp[1] + " " + temp[2] + " " + temp[3] + " " + temp[4] + " " + temp[5]);
//        rollDice(3,temp);
//        System.out.println(temp[0] + " " + temp[1] + " " + temp[2] + " " + temp[3] + " " + temp[4] + " " + temp[5]);

        System.out.println(canDoAction("swap 5 0 ","R0,R1,S3,J1",temp));
    }


    /**
     * Check if the specified structure can be built next, given the
     * current board state. This method should check that the build
     * meets the constraints described in section "Building Constraints"
     * of the README file.
     *
     * @param structure: The string representation of the structure to
     *        be built.
     * @param board_state: The string representation of the board state.
     * @return true iff the structure is a possible next build, false
     *         otherwise.
     */
    /** Task 8 was completed by Steven Liu on the 15th of September 2022*/
    public static boolean isStructureValid(String structure, String board_state){
        int count=0;
        String BC="";
        if(structure.charAt(0)=='R'){BC="R0,R1,R2,R3,R4,R5,R6,R7,R8,R9,R10,R11,R12,R13,R14,R15";}
        else if(structure.charAt(0)=='S'){BC="S3,R2,S4,R5,S5,R7,S7,R9,S9,R11,S11";}
        else if(structure.charAt(0)=='C'){BC="R1,C7,R4,C12,R13,C20,R15,C30";}
        int index=BC.indexOf(structure);
        String[] split= board_state.split(",");
        String[] BC_split=BC.substring(0,index-1).split(",");
        for(String s: BC_split){
            for(String str: split){
                if(s.equals(str)){
                    count+=1;
                }
            }
        }
        return count== BC_split.length;
    }
    public static boolean checkBuildConstraints(String structure,
						String board_state) {
        String BC_R="R0,R1,R2,R3,R4,R5,R6,R7,R8,R9,R10,R11,R12,R13,R14,R15";
        String BC_S="S3,R2,S4,R5,S5,R7,S7,R9,S9,R11,S11";
        String BC_C="R1,C7,R4,C12,R13,C20,R15,C30";
        String BC_J="J1,J2,J3,J4,J5,J6";
        String BC_K="K1,K2,K3,K4,K5,K6";
        String board_state_substr=board_state.substring(0,board_state.length());
        String[] split= board_state_substr.split(",");
        if(structure.charAt(0) == 'J') {
            int count=0;
            int index=BC_J.indexOf(structure);
            if(index==0){return true;}
            String[] BC_J_split=BC_J.substring(0,index-1).split(",");
            String[] BC_K_split=BC_K.substring(0,index-1).split(",");
            for(String s: BC_J_split){
                for(String str: split){
                    if(s.equals(str)){count+=1;}
                }
            }
            if(count==0){
                for(String s: BC_K_split){
                    for(String str: split){
                        if(s.equals(str)){count+=1;}
                    }
                }
                return count== BC_J_split.length;
            }else{return count== BC_J_split.length;}
        }
        else if (structure.charAt(0)=='R'){
            if(structure.equals("R0")){return true;}
            else{
                return isStructureValid(structure,board_state);
            }
        }
        else if (structure.charAt(0)=='S'){
            if(structure.equals("S3")){return true;}
            else{
                return isStructureValid(structure,board_state);
            }
        }
        else{
            return isStructureValid(structure,board_state);
        }
	  // FIXME: Task #8
    }

    /**
     * Check if the available resources are sufficient to build the
     * specified structure, without considering trades or swaps.
     *
     * @param structure: The string representation of the structure to
     *        be built.
     * @param resource_state: The available resources.
     * @return true iff the structure can be built with the available
     *         resources, false otherwise.
     */
    //Written by Renbin He
    public static boolean checkResources(String structure,
                                         int[] resource_state) {
        // FIXME: Task #7
        switch (structure.charAt(0)) {
            // The format of resources is {Ore, Grain, Wool, Lumber, Bricks, Gold}
            case 'J':
            case 'K':
                // Knight and Joker needs Ore, Grain and Wool
                if (resource_state[0]>=1 && resource_state[1]>=1 && resource_state[2]>=1){
                return true;
            }
            break;
            case 'S':
                // settlement needs Grain, Wool, Lumber and Brick
                if (resource_state[1] >= 1 && resource_state[2]>= 1 && resource_state[3] >= 1 && resource_state[4] >= 1){
                return true;
            }
            break;
            case 'C':
                // City needs 3 Ore and 2 Grain
                if (resource_state[0] >= 3 && resource_state[1] >= 2){
                return true;
            }
            break;
            case 'R':
                // A Road needs Lumber and Brick
                if (resource_state[3] >= 1 && resource_state[4] >= 1){
                return true;
            }
            break;
            default :
                return false;
        }
        return false;
    }

    /**
     * Check if the available resources are sufficient to build the
     * specified structure, considering also trades and/or swaps.
     * This method needs access to the current board state because the
     * board state encodes which Knights are available to perform swaps.
     *
     * @param structure: The string representation of the structure to
     *        be built.
     * @param board_state: The string representation of the board state.
     * @param resource_state: The available resources.
     * @return true iff the structure can be built with the available
     *         resources, false otherwise.
     */
    // Written by Renbin He
    public static boolean checkResourcesWithTradeAndSwap(String structure,
							 String board_state,
							 int[] resource_state) {
//        System.out.println(resource_state[0] +" " + resource_state[1]+ " " + resource_state[2]+ " " + resource_state[3]+ " " + resource_state[4]+ " " + resource_state[5]);
        char c = structure.charAt(0);
        int ore = resource_state[0];
        int grain = resource_state[1];
        int wool = resource_state[2];
        int timber = resource_state[3];
        int brick = resource_state[4];
        int gold = resource_state[5];
        switch (c) {
            case 'R':
                if (timber == 0 && brick > timber) {
                    if (!(board_state.contains("J6") || board_state.contains("J3")) && gold < 2){
                        return false;
                    }
                } else if (brick == 0 && timber > brick) {
                    if (!(board_state.contains("J6") || board_state.contains("J4")) && gold < 2){
                        return false;
                    }
                } else if (brick + timber == 0) {
                    if (!((board_state.contains("J6") && board_state.contains("J4"))
                            || (board_state.contains("J3") && board_state.contains("J6"))
                            || (board_state.contains("J3") && board_state.contains("J4")))
                            && gold < 4) {
                        return false;
                    }
                }break;
            case 'J':
                if (ore == 0) {
                    if (ore == grain && wool >= 1) {
                        if (!(board_state.contains("J1") && board_state.contains("J2")) && gold < 4) {
                            return false;
                        }
                    } else if (ore == wool && grain >= 1) {
                        if (!(board_state.contains("J1") && board_state.contains("J3")) && gold < 4) {
                            return false;
                        }
                    } else if (grain >= 1 && wool >= 1) {
                        if (!(board_state.contains("J1")) && gold < 2) {
                            return false;
                        }
                    } else {
                        if (!(board_state.contains("J1") && board_state.contains("J2") && board_state.contains("J3")) && gold < 6) {
                            return false;
                        }
                    }
                } else if (grain == 0) {
                    if (grain == wool && ore >= 1) {
                        if (!(board_state.contains("J2") && board_state.contains("J3")) && gold < 4) {
                            return false;
                        }
                    } else if (ore >= 1 && wool >= 1) {
                        if (!(board_state.contains("J2")) && gold < 2) {
                            return false;
                        }
                    } else {
                        if (!(board_state.contains("J2") && board_state.contains("J1") && board_state.contains("J3")) && gold < 6) {
                            return false;
                        }
                    }
                } else if (wool == 0) {
                    if (ore >= 1 && grain >= 1) {
                        if (!(board_state.contains("J3")) && gold < 2) {
                            return false;
                        }
                    } else {
                        if (!(board_state.contains("J2") && board_state.contains("J3") && board_state.contains("J1")) && gold < 6) {
                            return false;
                        }
                    }
                }break;
            case 'C':
                int counts0 = 0;
                int counts1 = 0;
                int counts2 = 0;
                int counts3 = 0;
                int counts4 = 0;
                for (int i = 0 ; i < 2 ; i++) {
                    if (resource_state[i]==0) {
                        counts0++;
                    } else if (resource_state[i]==1){
                        counts1++;
                    } else if (resource_state[i]==2){
                        counts2++;
                    } else if (resource_state[i]==3){
                        counts3++;
                    } else {
                        counts4++;
                    }
                }
//                System.out.println(counts0+" " + counts1 + " " + counts2 + " " + counts3 + " " +counts4);
                if (!board_state.contains("J")) { //no swap case
                    if (ore+grain < 5) {
                        if (gold <= (5-(ore+grain))*2 && ore < grain) {
                            return false;
                        } else if (gold < (5-(ore+grain))*2 && ore > grain) {
                            return false;
                        }
                    } else if (counts0 > 0) {
                        return false;
                    }
                } else { // with swap
                    if(!(board_state.contains("J1") || board_state.contains("J6"))) {
                        if (ore < 3 && gold < (5-ore)*2) {
                            return false;
                        }
                    } else if (!(board_state.contains("J2") || board_state.contains("J6"))) {
                        if (grain < 2 && gold < (5-grain)*2) {
                            return false;
                        }
                    } else if (ore < 3 && grain >=2) {
                        if(board_state.contains("J1") || board_state.contains("J6")) {
                            int getIt = 0;
                            for (int i = 1; i < resource_state.length; i++) {
                                if (i == 1) {
                                    if (resource_state[i] - 2 == 3-ore) {
                                        getIt++;
                                    }
                                } else {
                                    if (resource_state[i] == 3-ore) {
                                        getIt++;
                                    }
                                }
                            }
                            if (getIt < 1) {
                                return false;
                            }
                        }
                    } else if (ore >= 3 && grain < 2) {
                        if (board_state.contains("J2") || board_state.contains("J6")) {
                            int getIt = 0;
                            for (int i = 0; i < resource_state.length; i++) {
                                if (i == 0) {
                                    if (resource_state[i] - 3 == 2-grain) {
                                        getIt++;
                                    }
                                } else if (i == 1) {
                                    continue;
                                } else {
                                    if (resource_state[i] == 3-ore) {
                                        getIt++;
                                    }
                                }
                            }
                            if (getIt < 1) {
                                return false;
                            }
                        }
                    } else if (ore < 3 && grain < 2) {
                        if (ore + grain <= 3) {
                            return false;
                        }
                    }
                }break;
            case 'S':
                int count0 = 0;
                int count1 = 0;
                int count2 = 0;
                int count3 = 0;
                int count4 = 0;
                for (int i = 1 ; i < 5; i++) {
                    if (resource_state[i]==0) {
                        count0++;
                    } else if (resource_state[i]==1){
                        count1++;
                    } else if (resource_state[i]==2){
                        count2++;
                    } else if (resource_state[i]==3){
                        count3++;
                    } else {
                        count4++;
                    }
                }
                if (!board_state.contains("J")) { //no swap case
                    if (count3 > 0 && count1 < 3) {
                        return false;
                    } else if (count4 > 0) {
                        return false;
                    } else if (count0 > 0 && gold < (count0*2)) {
                        return false;
                    }
                } else { // with swap
                    if (!(board_state.contains("J2") || board_state.contains("J6"))) {
                        if (grain < 1 && gold < 2) {
                            return false;
                        }
                    } else if (!(board_state.contains("J3") || board_state.contains("J6"))) {
                        if (wool < 1 && gold < 2) {
                            return false;
                        }
                    } else if (!(board_state.contains("J4") || board_state.contains("J6"))) {
                        if (timber < 1 && gold < 2) {
                            return false;
                        }
                    } else if (!(board_state.contains("J5") || board_state.contains("J6"))) {
                        if (brick < 1 && gold < 2) {
                            return false;
                        }
                    } else if (!(board_state.contains("J2") || board_state.contains("J3") || board_state.contains("J4") ||
                            board_state.contains("J5"))) {
                        if (board_state.contains("J6")) {
                            if (count0 > 1 && gold < (count0*2)) {
                                return false;
                            }
                        }
                    }
                }

        }
	return true; // FIXME: Task #12
    }



    /**
     * Check if a player action (build, trade or swap) is executable in the
     * given board and resource state.
     *
     * @param action: String representatiion of the action to check.
     * @param board_state: The string representation of the board state.
     * @param resource_state: The available resources.
     * @return true iff the action is applicable, false otherwise.
     */
    //Written by Ruimeng YE
    public static boolean canDoAction(String action, String board_state, int[] resource_state) {
        //divide action into 3 types
        System.out.println(action);
        System.out.println(board_state);
        System.out.println(resource_state[0] + " " + resource_state[1] + " " + resource_state[2] + " " + resource_state[3] + " "+ resource_state[4] +
                " " + resource_state[5]);
        String[] actionType=action.split(" ");
        //check action and board state
        if (!isActionWellFormed(action)||!isBoardStateWellFormed(board_state)){
            return false;
        }
        return switch (actionType[0]){
               //build e.g. "Build R2","Build J1"
                case "build" ->
                        (checkBuildConstraints(actionType[1],board_state)
                                && checkResources(actionType[1],resource_state));
                //trade 2 gold
                case "trade"->
                        (resource_state[5]>=2);
                //swap e.g."swap 1 4" means exchanging 1 Grain for 1 Brick.
                case "swap" ->
                        ((resource_state[(Integer.parseInt(actionType[1]))]>0)
                                && board_state.contains("J"+(Integer.parseInt(actionType[2])+1)));
                default ->
                    false;
            };
        // FIXME: Task #9
    }



    /**
     * Check if the specified sequence of player actions is executable
     * from the given board and resource state.
     *
     * @param actions: The sequence of (string representatins of) actions.
     * @param board_state: The string representation of the board state.
     * @param resource_state: The available resources.
     * @return true iff the action sequence is executable, false otherwise.
     */
    public static boolean canDoSequence(String[] actions, String board_state, int[] resource_state) {
        //check each action
        char c = actions[0].charAt(0);
        int[] resource_state_clone = resource_state.clone();
        String board_state_clone = board_state;
        int ore = resource_state[0];
        int grain = resource_state[1];
        int wool = resource_state[2];
        int timber = resource_state[3];
        int brick = resource_state[4];
        int gold = resource_state[5];
        for (String action:actions){
            if (!canDoAction(action,board_state,resource_state)){
                return false;
            }
            //update board state and resource state

            return switch (c) {
                case 'b' -> {
                    String[] doAction = action.split(" ");
                    board_state = board_state + doAction[1];
                    yield true;
                }
                case 't' -> {
                    gold -= 2;
                    yield true;
                }
                case 's' -> {
                    String[] doAction = action.split(" ");
                    resource_state_clone[Integer.parseInt(doAction[1])] -= 1;
                    resource_state_clone[Integer.parseInt(doAction[2])] += 1;
                    yield true;
                }
                default -> false;
            };
        }
        return true;
        //

        // FIXME: Task #11
    }



    /**
     * Find the path of roads that need to be built to reach a specified
     * (unbuilt) structure in the current board state. The roads should
     * be returned as an array of their string representation, in the
     * order in which they have to be built. The array should _not_ include
     * the target structure (even if it is a road). If the target structure
     * is reachable via the already built roads, the method should return
     * an empty array.
     * 
     * Note that on the Island One map, there is a unique path to every
     * structure. 
     *
     * @param target_structure: The string representation of the structure
     *        to reach.
     * @param board_state: The string representation of the board state.
     * @return An array of string representations of the roads along the
     *         path.
     */
        public static String[] pathTo(String target_structure,
                String board_state) {
            String[] result = {};
            return result; // FIXME: Task #13
        }


        /**
         * Generate a plan (sequence of player actions) to build the target
         * structure from the given board and resource state. The plan may
         * include trades and swaps, as well as bulding other structures if
         * needed to reach the target structure or to satisfy the build order
         * constraints.
         *
         * However, the plan must not have redundant actions. This means it
         * must not build any other structure that is not necessary to meet
         * the building constraints for the target structure, and it must not
         * trade or swap for resources if those resources are not needed.
         *
         * If there is no valid build plan for the target structure from the
         * specified state, return null.
         *
         * @param target_structure: The string representation of the structure
         *        to be built.
         * @param board_state: The string representation of the board state.
         * @param resource_state: The available resources.
         * @return An array of string representations of player actions. If
         *         there exists no valid build plan for the target structure,
         *         the method should return null.
         */
    public static String[] buildPlan(String target_structure,
				     String board_state,
				     int[] resource_state) {
	 return null; // FIXME: Task #14
    }

}
