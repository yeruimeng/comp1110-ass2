package comp1110.ass2.gittest;

public class B {
    @Override
    public String toString() {
        System.out.println();
        System.out.println("Hello");
        return "B";

    }
}
