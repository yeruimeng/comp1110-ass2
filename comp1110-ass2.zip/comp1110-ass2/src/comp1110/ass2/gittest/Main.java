package comp1110.ass2.gittest;

public class Main {
    public static void main(String[] args) {
        A a = new A();

        C c = new C();
        B b = new B();
    }

}
