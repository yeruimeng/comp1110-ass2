package comp1110.ass2.gittest;

public class C {
    @Override
    public String toString() {
        System.out.println();
        return "C";
    }
}
