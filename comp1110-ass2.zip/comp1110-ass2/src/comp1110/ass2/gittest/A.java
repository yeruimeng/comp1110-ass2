package comp1110.ass2.gittest;

public class A {
    @Override
    public String toString() {
        System.out.println();
        return "A";
    }
}
