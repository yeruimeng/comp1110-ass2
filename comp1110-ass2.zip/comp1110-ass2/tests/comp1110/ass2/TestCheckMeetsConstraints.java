package comp1110.ass2;


import static org.junit.jupiter.api.Assertions.assertEquals;

import comp1110.ass2.CatanDice;
import  org.junit.jupiter.api.Test;

//@org.junit.jupiter.api.Timeout(value = 1000, unit = MILLISECONDS)

public class TestCheckMeetsConstraints {
    private String errorPrefix(String inputOne, String inputTwo) {
        return "CatanDice.TestCheckMeetsConstraints(\"" + inputOne + "\" + " + inputTwo + "\")";
    }

    private void test(String inputOne, String inputTwo, boolean expected) {
        String errorPrefix = errorPrefix(inputOne, inputTwo);
        boolean output = CatanDice.checkMeetsConstraints(inputOne, inputTwo);
        assertEquals(expected, output, errorPrefix);
    }

    @Test
    public void outputTrue() {
        test("", "R0", true);
        test("R0", "R0,C7,K5", true);
        test("K4,R2", "J5,J3,C20,K4,K6,R2", true);
        test("", "", true);
    }
    @Test
    public void outputFalse() {
        test("R0", "", false);
        test("R1", "R0,C7,K5", false);
        test("K4,R2", "J5,J3,C20,K4,K6,R3", false);
    }

    public static void main(String[] args) {
        TestIsActionWellFormed tests = new TestIsActionWellFormed();
        System.out.println("testing...");
        tests.trivialTrue();
        tests.trivialFalse();
        System.out.println("all done!");
    }
}