package comp1110.ass2;

import java.util.*;
import org.junit.jupiter.api.Test;
import static comp1110.ass2.HelperExamples.*;

import static java.util.concurrent.TimeUnit.MILLISECONDS;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

// @org.junit.jupiter.api.Timeout(value = 1000, unit = MILLISECONDS)

public class IsStructureValidTest {

    private String errorPrefix(String board_state, String target) {
        return "StructureCheck.isStructureValid(" + target + ", " + board_state + ")";
    }

    private void test(String s, String b, boolean answer) {
        String errorPrefix = errorPrefix(b, s);
        boolean out = CatanDice.isStructureValid(s,b);;
        assertEquals(answer, out, errorPrefix);
    }

    int count_actions(String prefix, String[] plan) {
        int n = 0;
        for (int i = 0; i < plan.length; i++)
            if (plan[i].startsWith(prefix))
                n += 1;
        return n;
    }

    int n_pos = 0;
    int n_neg = 0;

    public void makeTests(String[] board, String[] target, String[][][] plans) {
        for (int i = 0; i < board.length; i++) {
            if (plans[i] != null) {
                int n_build = count_actions("build", plans[i][0]);
                if (n_build == 1)
                    n_pos += 1;
                else
                    n_neg += 1;
                test(target[i], board[i], (n_build == 1));
            }
        }
    }

    @Test
    public void testSetValid() {
        makeTests(HelperExamples.valid_board,
                HelperExamples.valid_target,
                HelperExamples.valid_plans);
    }

    @Test
    public void testSetInValid() {
        makeTests(HelperExamples.invalid_board,
                HelperExamples.invalid_target,
                HelperExamples.invalid_plans);
    }

    public static void main(String[] args) {
        IsStructureValidTest tests = new IsStructureValidTest();
        System.out.println("testing...");
        tests.testSetValid();
        tests.testSetInValid();
        System.out.println("all done! (" + tests.n_pos + " pos, " + tests.n_neg + " neg)");
    }
}