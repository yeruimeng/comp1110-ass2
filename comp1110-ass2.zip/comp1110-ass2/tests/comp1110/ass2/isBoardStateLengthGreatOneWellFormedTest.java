package comp1110.ass2;

import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

class isBoardStateLengthGreatOneWellFormedTest {
    private String errorPrefix(String state) {
        return "CatanDice.isBoardStateWell(" + state + ")";
    }
    private void test(String in, boolean expected) {
        String errorPrefix = errorPrefix(in);
        boolean out = CatanDice.isBoardStateWell(in);
        assertEquals(expected,out,errorPrefix);
    }

    public void StateNotWellFormed() {
        test("1C",false);
        test("RR",false);
        test("C11", false);
        test("1K",false);
        test("k1",false);
        test("K2;R1",false);
        test("C7,K0",false);
        test("R1,R2,K0,S3",false);
    }

    public void StateWellFormed(){
        test("C7",true);
        test("R1,R2,K1,S3",true);
        test("C30",true);
        test("K6",true);
        test("S9",true);
    }

    @Test
    public void TestStateNotWellFormed() {StateNotWellFormed();}
    @Test
    public void TestStateWellFormed() {StateWellFormed();}

}