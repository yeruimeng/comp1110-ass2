# New Code for Deliverable D2D

## < u7133453 > < Renbin He >

For Deliverable D2D, I contributed the following new statements of original code:

- For the task 3, I create the method [isBoardStateWell()](https://gitlab.cecs.anu.edu.au/u7133453/comp1110-ass2/-/blob/main/src/comp1110/ass2/CatanDice.java#L33-L100) in the CatanDice class to check is the board state well form or not if it's length greater than 1. 
- I write the unit test for the above method [isBoardStateLengthGreatOneWellFormedTest()](https://gitlab.cecs.anu.edu.au/u7133453/comp1110-ass2/-/blob/main/tests/comp1110/ass2/isBoardStateLengthGreatOneWellFormedTest.java).


(Follow the example give above to list at least 10 statements of original code contributions made by you, but not substantially more; choose your best. Notice that the example above links directly to the code as well as providing a brief description.   
Please follow that example to link to your code.  You can create the link by browsing your code in gitlab, and then clicking on the line number of the first line, and then shift-clicking on the line number of the last line in the region you want to select.  
If you do that correctly, the URL for that selection will be in the navigation bar of your browser.  
After you commit and push your statement, you should check that all of the links are correctly working.)