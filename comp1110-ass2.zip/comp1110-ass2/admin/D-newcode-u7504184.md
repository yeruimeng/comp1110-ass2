# New Code for Deliverable D2D

## < uid > < name >

For Deliverable D2D, I contributed the following new statements of original code:

- Add the method [checkMeetsConstraints()](https://gitlab.cecs.anu.edu.au/u7133453/comp1110-ass2/-/blob/main/src/comp1110/ass2/CatanDice.java#L6-19) function to ClassDice class
- I write the test for the above method [TestCheckMeetsConstraints()](https://gitlab.cecs.anu.edu.au/u7133453/comp1110-ass2/-/blob/main/tests/comp1110/ass2/TestCheckMeetsConstraints.java#L1-43).
- etc.

(Follow the example give above to list at least 10 statements of original code contributions made by you, but not substantially more; choose your best. Notice that the example above links directly to the code as well as providing a brief description.   
Please follow that example to link to your code.  You can create the link by browsing your code in gitlab, and then clicking on the line number of the first line, and then shift-clicking on the line number of the last line in the region you want to select.  
If you do that correctly, the URL for that selection will be in the navigation bar of your browser.  
After you commit and push your statement, you should check that all of the links are correctly working.)
