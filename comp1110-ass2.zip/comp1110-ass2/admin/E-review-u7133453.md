## Code Review

Reviewed by: Renbin He, u7133453

Reviewing code written by: Steven Liu, u7433891

Component:
Task 8
-[isStructureValid()](https://gitlab.cecs.anu.edu.au/u7133453/comp1110-ass2/-/blob/main/src/comp1110/ass2/CatanDice.java#L201-218) in the CantanDice class
-[checkBuildConstraints()](https://gitlab.cecs.anu.edu.au/u7133453/comp1110-ass2/-/blob/main/src/comp1110/ass2/CatanDice.java#L219-264) in the CantanDice class

### Comments
In this code review document, I choose to review is checkBuildConstraints() method.
The best features of this method is this method uses strong for loop and subString which clearly break the whole input string to char and 
then check each char is valid or not in the setting String(BC_J, BC_K, etc). 
Also, this method is used for(:) iteration which makes code briefly. And this method's program decomposition is appropriate.
The helper method (isStructureValid()) has an appropriate name which is not ambiguous when other users watch this method. 
However, in those methods, they are lack some comments in some key features which is not very easy to understand those key features.
Overall, those methods follow Java code conventions and have a consistent style throughout.
