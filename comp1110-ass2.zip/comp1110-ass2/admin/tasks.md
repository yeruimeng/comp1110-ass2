# COMP1110 Assignment 2 Group Tasks

For each task or sub-task, record who is responsible, the deadline, and
any dependencies.

Use the entries below as an example.

## Week 4

Everyone: create application skeleton - meeting 15:00PM  20 AUG

## Week 5

Zhang San: Task 3 isPlayerStateWellFormed - 23 Mar

Jane Bloggs: Task 5 drawTileFromBag - 23 Mar

Erika Mustermann: Task 6 refillFactories - 25 Mar (depends on Task 5)

## Week 6

...

## Mid-Semester Break

## Week 7

## Week 8

## Week 9

## Week 10

## Week 11
