## Code Review

Reviewed by: Ruimeng YE, u7504184

Reviewing code written by: Renbin He u7133453

Component: [isActionWellFormed()](https://gitlab.cecs.anu.edu.au/u7133453/comp1110-ass2/-/blob/main/src/comp1110/ass2/CatanDice.java#L122-157),Test

### Comments 

The code is well-documented and the best feature of this method is this method uses clear structure of loop. It divides cases into
trade and swap to check the if the action is well-formed.
And the decomposition of the method is appropriate because it chooses to use the Array to describe different statements 
which makes the method structure more clear.
Also, the methods and variables are properly named which helps the code more understandable.
The only thing I think can be improved is that some "if" statements can be simplified to make the code more concise.
But in general, the code follows Java code conventions and the style is consistent throughout.


