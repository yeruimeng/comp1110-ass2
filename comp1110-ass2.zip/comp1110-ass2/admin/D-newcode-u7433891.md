# New Code for Deliverable D2D

## < u7433891 > < Steven Liu >

For Deliverable D2D, I contributed the following new statements of original code:

- For the task 8, I create the method [isStructureValid()](https://gitlab.cecs.anu.edu.au/u7133453/comp1110-ass2/-/blob/main/src/comp1110/ass2/CatanDice.java#L190-203) in the CatanDice class to check if the specified structure can be built next and also check that the build meets the constraints.
- I wrote the unit test for the method above [IsStructureValid](https://gitlab.cecs.anu.edu.au/u7133453/comp1110-ass2/-/blob/main/tests/comp1110/ass2/IsStructureValidTest.java).
