## Code Review

Reviewed by: Steven Liu, u7433891

Reviewing code written by: Ruimeng Ye, u7504184

Component: tests,the method of [TestCheckMeetsConstraints](https://gitlab.cecs.anu.edu.au/u7133453/comp1110-ass2/-/blob/main/tests/comp1110/ass2/TestCheckMeetsConstraints.java#L1-43)

### Comments 

The code is well-documented, including details of comment for the code. 
The best features of this code are the structure of the code is well-performed,
easy to maintain code, the code is very readable, and it follows the compliance.
The method structure is appropriate but still some repeat code appears.
It follows the Java code conventions and the style is consistent throughout.


